package com.MarieTraiteur.Api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMarieTraiteurApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMarieTraiteurApplication.class, args);
	}

}
